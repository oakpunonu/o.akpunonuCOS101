fn my_grade() {

    //function body 
    println!("Greeting from function my_grade!");
}

fn main() {

    //calling a function
    my_grade();

}
