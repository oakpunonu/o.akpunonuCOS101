fn main() {
    let fullname = " Pan-Atlantic University ";
    println!();
    println!("Name: {}", fullname);
    println!();
    println!("Before Trim ");
    println!("length is {}", fullname.len());
    println!();
    println!("After trim ");
    println!("length is {}",fullname.trim().len());
    
}
