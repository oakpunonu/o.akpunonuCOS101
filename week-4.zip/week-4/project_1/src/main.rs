fn main() {
    
    let distance1 = 80.00;
    let distance2 = 120.00;
    let mut _result: f32;

    let time1 = 2.00;
    let time2 = 4.00;
    let mut result:f32;

    result = distance1/time1 ;
    println!("80 miles 2 hours: {} ",result);

    result = distance2/time2 ;
    println!("120 miles 4 hours: {} ",result);
}
