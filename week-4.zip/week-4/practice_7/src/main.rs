fn main() {
   let k1 = "Yemisi".to_string();
   let k2 = " shyllon".to_string();
   let k3 = " museum".to_string();
   let k4 = " of" .to_string();
   let k5 = " Art, " .to_string();
   let k6 = " PAU" .to_string();

   // format macro
   let k7 = format!("{} {} {} {} {} {}",k1,k2,k3,k4,k5,k6);
   // print output
   println!("\n {}",k7);
}
