fn main() {
    let empty_string = String::new();
    println!("Length of empty_string is {}",empty_string.len());

    let content_string = String::from("ComputerScience");
    println!("Length of content_string is {}",content_string.len());
}
