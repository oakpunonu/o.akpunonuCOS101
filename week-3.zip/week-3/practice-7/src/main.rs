fn main() {
    let float_with_seperator = 11_000.555_001;
    println!(" float value {}",float_with_seperator );


    let int_with_seperator = 50_000;
    println!("Int value {}", int_with_seperator );
}
