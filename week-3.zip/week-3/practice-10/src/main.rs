fn main() {
   let sum = 5550 + 7310;
   println!("The sum of 5550 and 7310 is{}",sum );


   let difference:f32 = 95.50 - 4.30;
   println!("The difference of 95.5 and 4.3 is: {}", difference );


   let product:u32 = 4 * 30;
   println!("The multiplication of 4 and 30 is:{}", product );


   let quotient:f64 = 56.70 / 32.20;
   println!("The division of 56.7 and 32.2 is: {}",quotient );


   let remainder:f64 = 43.0 % 5.0;
   println!("The remainder of 43 and 5 is: {}",remainder );
}