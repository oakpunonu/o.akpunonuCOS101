fn main() {
    let result = 10;       // 132 by default
    let age:u32 = 20;
    let sum:i32 = 5 - 15;

    println!("Result value is {} ",result);
    println!("Age is {} ",age);
    println!("Sum is {} ",sum);
}
