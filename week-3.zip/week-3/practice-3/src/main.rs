fn main() {
    let result = 10.00;      //f64 by default
    let interest:f32 = 8.35;
    let cost:f64 = 15000.600;   //double precision

    println!("result value is {}",result);
    println!("interest is {}",interest);
    println!("cost is {}",cost);
}
