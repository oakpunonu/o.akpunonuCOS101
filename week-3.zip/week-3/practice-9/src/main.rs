fn main() {
    let mut fees = 25_0000;
    println!("fees is {}",fees );


    let fees = 35_000;
    println!(" fees changed is {}",fees );
}
