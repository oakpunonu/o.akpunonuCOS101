fn main() {
    let interest:f32 = 8.0;
    println!("interest is: {}",interest );
}
