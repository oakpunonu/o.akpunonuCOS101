fn main() {
    let isgood:bool = true;
    println!("PAU is a good university? {}",isgood);
}
