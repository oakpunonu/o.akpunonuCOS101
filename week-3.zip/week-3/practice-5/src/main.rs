fn main() {
    let special_character = "@"; //default
    let alphabet:char = 'B';
    let surname = "Bolaji";
    let first_name = "Michael;
    let middle_name = "Gboyega";


    println!(" ");
    println!("Special character: {}",special_character);
    println!("Alphabet: {}",alphabet);
    println!("Name; {} {} {}",surname,middle_name,first_name");
}