fn main() {
    let school_string = "School os science and technology"; // string type
    let rating_float = 5.0;                         // float type
    let is_growing_boolean = true;                  // boolean type
    let department_interger = 3;                    // interger type


    println!("School name is: {}",school_string );
    println!("School rating on 5 is: {}",rating_float);
    println!("School is growing : {}",is_growing_boolean);
    println!("Number of Departments : {}",department_interger);
}
