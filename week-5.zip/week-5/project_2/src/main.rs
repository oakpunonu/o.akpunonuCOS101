use std::io;
fn main() {
   let mut exp = String::new();
   let mut input2 = String::new();

   let a = 1_560_000;
   let b = 1_480_000;
   let c = 1_300_000;
   let d = 100_000;

    println!("Are you expereinced: ");
         io::stdin()
         .read_line(&mut exp)
         .expect("Not a valid string");
    let expereinced:bool = exp.trim().parse().expect("Not Valid");

    println!("Enter your age: ");
         io::stdin()
         .read_line(&mut input2)
         .expect("Not a valid string");
    let age:i32 = input2.trim().parse().expect("Not a valid number");

    if expereinced == true && age >= 40 {
    	println!("incentive is {}", b);
    }
    else if expereinced == true && age >= 30 && age < 40 {
    	println!("incentive IS {}", b);
    }
    else if expereinced == true && age < 30 && age >= 18 {
    	println!("incentive is {}", c);
    }
    else if expereinced == false && age >= 18 {
         println!("incentive is {}", d);
    }
    else {
    	println!("We don't employ less than legal age");
    }
}
