use std::io;

fn main() {
    println!("Welcome to E's cafe!");

    let mut serve = String::new();

    println!("How do we serve you?");
    io::stdin()
        .read_line(&mut serve)
        .expect("failed to read line");

    let place_order: &str  = serve.trim();

    println!("Here is our Menu: (N/B: if you make an order of #10,000 and above, you will be given a discount of 5%)");
    
    let items = ["Pounded yam and edikanikon soup", "fried rice and chicken", "eba and egusi soup", "Amala and ewedu soup", "plantain"];
    let prices = [3500, 3000, 2500, 2000, 3000];

    for food in 0..items.len() {
    	println!("{}: #{}", items[food], prices[food]);
    }
   
   // Type of food
   let mut choice = String::new();

   println!("Enter the type of food:");
   io::stdin()
       .read_line(&mut choice);
       
   // Quantity of food
   let mut quantity  = String::new();

    println!("Enter the quantity you need:");
    io::stdin()
    .read_line(&mut quantity)
    .expect("Failed to read line");
  let qty: u32 = quantity.trim().parse().expect("Not a valid quantity");

  // Index of the user's choice
  if let Some(p) = items.iter().position(|&item| item.trim() == choice.trim()) {
  	
     let price  = prices[p];

     //calculate total price 
     let total_price = price * qty;

     // Applying a 5% discount
     let discount = if total_price > 10000 {
     	total_price - (total_price * 5 / 100)
     }  else {
     	total_price
     };
  	
  	println!("You ordered {} {} Total price: #{}", quantity, choice, discount);

  	// Another order
  	let mut Another = String::new();

  	println!("Would you like to place another order? (Yes/No)");
  	io::stdin()
  	      .read_line(&mut Another)
  	      .expect("Failed to read line");

  	if Another.trim() == "Yes" {
  		println!("Please continue with your additional order.");
  	}
  	else {
  		println!("Thank you for your order!");
  	}
  } else {
  	println!("{} is not on the menu.", choice);
  }
} 
